auth = 1

async def main(data):
    Newtext =f'**There are {len(data.Commands)} commands**\n'
    for command in data.Commands:
        Newtext = Newtext+command+'\n'
        
    embed = data.Discord.Embed(title='Commands',description=Newtext)
    
    
    await data.Channel.send(embed= embed)
    
def help():
    return "Shows a list of all commands."
