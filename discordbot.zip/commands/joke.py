auth = 1

async def main(data):
    catData = data.Requests.get('https://v2.jokeapi.dev/joke/any?type=single')
    
    
    await data.Channel.send(data.Json.loads(catData.content.decode('utf-8'))['joke'])

def help():
    return "Gets a random joke  from the internet. Powered by v2.jokeapi.dev."