auth = 1

async def main(data):
    try:
        if data.TextList[1]:
            filename = ''
            try:
                filename = data.Files[data.Commands.index(data.TextList[1])]
            except:
                data.Channel.send("Unknow command.")
            
            localData = {}
            file = open("commands/"+filename,"r")
            exec(file.read(),globals(),localData)
            
            title = 'Help: "'+data.TextList[1] + '", Auth level: ' + str(localData['auth'])
            
            embed = data.Discord.Embed(title=title,description=localData['help']())
            await data.Channel.send(embed=embed)
    except:
        embed = data.Discord.Embed(title="Help",description=f"You can use {data.Prefix}listCmds to see the list of commands.\nUse help <command> to see more info on that command.")
        await data.Channel.send(embed=embed)
        
        
def help():
    return "Why are you lookin? You can use this command to get info from commands."