auth = 3

async def main(data):
    
    if data.TextList[1]:
            delta = data.Datetime.timedelta()
            user = data.TextList[1]
            guild = data.Message.guild
            
            match user:
                case 'me':
                    await data.Message.author.timeout(delta)
                    await data.Channel.send(f'{data.Message.author} has unmuted themselves.')
                case 'others':
                    for member in guild.members:
                        if not (member == data.Message.author or member == data.Client.user):
                            await member.timeout(delta)
                    await data.Channel.send(f'{data.Message.author} has unmuted others.')

                case 'all':
                    for member in guild.members:
                        if not member == data.Client.user:
                            await member.timeout(delta)
                    await data.Channel.send(f'{data.Message.author} has unmuted all.')
                
                case _:
                    member = guild.get_member_named(user)
                    if member:
                        await member.timeout(delta)
                        await data.Channel.send(f'{data.Message.author} has unmuted {user}.')
                    else:
                        await data.Channel.send('Member not found')
                
    else:
          await data.Channel.send("Arg 1 must be a user or a selector")
    
def help():
    return "Unmute a user or a selector. They are <me>, <all>, and <others>."
