auth = 3


async def main(data):
    if len(data.TextList)<3:
        await data.Channel.send("Missing arguments")
        return


    if data.TextList[1]:
            
            delta = data.Datetime.timedelta(hours=float(data.TextList[2]))

            user = data.TextList[1]
            guild = data.Message.guild
            
            match user:
                
                case 'others':
                    for member in guild.members:
                        if not (member == data.Message.author or member == data.Client.user):
                            await member.timeout(delta)
                    await data.Channel.send(f'{data.Message.author} has muted others.')

                case 'all':
                    for member in guild.members:
                        if not member == data.Client.user:
                            await member.timeout(delta)
                    await data.Channel.send(f'{data.Message.author} has muted all.')
                
                case _:
                    member = guild.get_member_named(user)
                    if member:
                        await member.timeout(delta)
                        await data.Channel.send(f'{data.Message.author} has muted {user}.')
                    else:
                        await data.Channel.send('Member not found')
                
    else:
          await data.Channel.send("Arg 1 must be a user or a selector")
    

def help():
    return "Mute a user or a selector. They are <me>, <all>, and <others>."