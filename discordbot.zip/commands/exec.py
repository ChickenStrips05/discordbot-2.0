auth = 5

async def main(data):
    
    Newtext =''
    for i,text in enumerate(data.TextList):
        
        if i != 0:
            Newtext = Newtext+text+" "
    
    
    exec(Newtext)

def help():
    return "Run python code with exec() function."

