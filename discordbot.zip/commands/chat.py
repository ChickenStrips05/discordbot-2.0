auth = 1


async def main(data):
    try:
        Newtext =''
        for i,text in enumerate(data.TextList):
        
            if i != 0:
                Newtext = Newtext+text+" "
    
        
        await data.Channel.send(Newtext)
    except: 
        pass
    
    

def help():
    return "Send a chat message. Usefull with stacked commands."