auth = 2  # Set an appropriate auth level

async def main(data):
    voice_client = data.Client.voice_clients
    if voice_client:
        await voice_client[0].disconnect()
        await data.Channel.send("Left the voice channel.")
    else:
        await data.Channel.send("I'm not in a voice channel!")

def help():
    return "Makes the bot leave the vc"