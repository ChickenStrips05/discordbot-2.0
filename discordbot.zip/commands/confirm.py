auth = 1

async def main(data):
    
    if data.Confirm == False:
        file = open("cache/confirm.txt",'w')
        file.write(data.FileName)
        file.close

        await data.Channel.send(f'please confirm this action <{data.Prefix}y>,<{data.Prefix}n>.')
        
        
    else:
        await data.Channel.send("Yay")
    
    

def help():
    return "This is a test for the confirmation system."

