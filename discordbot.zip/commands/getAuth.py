auth = 4

async def main(data):
    if len(data.TextList) < 2:
        await data.Channel.send("Missing arguments")
        return
    
    username = data.TextList[1]
    guild = data.Message.guild

    def getAuthData():
        with open("users.json", 'r') as f:
            authdata = data.Json.loads(f.read())
        return authdata
    
    authdata = getAuthData()
    
    member = guild.get_member_named(username)
    if not member:
        await data.Channel.send('Member not found in guild')
        return
    
    for user in authdata['users']:
        
        if int(user['id']) == member.id:
            
            await data.Channel.send(f"Auth level of {username} is {user['lvl']}")
            return
    await data.Channel.send(f"Auth level of {username} is 1 ")

def help():
    return "Get the authorisation level of someone."
