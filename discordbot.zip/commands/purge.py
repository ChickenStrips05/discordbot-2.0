auth = 3

async def main(data):
    try:
        if data.TextList[1]:
            try:
                amount=int(data.TextList[1])
            except:
                 await data.Channel.send("Arg 1 must be an int")
    except:
            amount = 100
    
    
    await data.Channel.purge(limit = amount)

def help():
    return "Quickly deletes messages in the channel. You can set the amout of messages to delete."
    

