auth = 1


async def main(data):
    await data.Channel.send(f"Hello, {data.Message.author}!")
    
    

def help():
    return "Greets the user."