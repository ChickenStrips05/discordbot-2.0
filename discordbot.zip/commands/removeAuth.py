auth = 4

async def main(data):
    if len(data.TextList) < 2:
        await data.Channel.send("Missing arguments")
        return
    
    user = data.TextList[1]
    guild = data.Message.guild

    def getAuthData():
        with open("users.json", 'r') as f:
            authdata = data.Json.loads(f.read())
        return authdata
    
    authdata = getAuthData()
    
    member = guild.get_member_named(user)
    if not member:
        await data.Channel.send('Member not found')
        return
    
    # Attempt to find and remove the user
    user_found = False
    for i, user in enumerate(authdata["users"]):
        if user["id"] == str(member.id):  # Match user by ID
            del authdata["users"][i]  # Remove the user
            user_found = True
            break
    
    if user_found:
        # Save the updated data
        with open('users.json', 'w') as f:
            f.write(data.Json.dumps(authdata))
        await data.Channel.send(f"User removed successfully.")
    else:
        await data.Channel.send(f"User not found in the database.")

def help():
    return "You can remove a user's authorisation"
