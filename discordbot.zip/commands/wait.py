auth = 1

async def main(data):
    if len(data.TextList) <2:
        await data.Channel.send('Missing arguments.')

    data.Time.sleep(float(data.TextList[1]))
    
    
def help():
    return "Wait for a specified amout of time. Useful for stacked commands."

