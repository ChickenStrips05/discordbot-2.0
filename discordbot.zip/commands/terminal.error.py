auth = 5

async def main(data):
    Newtext =''
    for i,text in enumerate(data.TextList):
        
        if i != 0:
            Newtext = Newtext+text+" "
            
    print(data.Color(Newtext,'Bright Red'))
    

def help():
    return "Prints error text to the terminal"