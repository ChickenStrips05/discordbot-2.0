auth = 2  # Set an appropriate auth level

async def main(data):
    voice_client = data.Client.voice_clients
    if voice_client:
        voice_client[0].stop()
        await data.Channel.send("Stopped the music.")
    else:
        await data.Channel.send("I'm not currently playing any music.")

def help():
    return "Stop playing music"