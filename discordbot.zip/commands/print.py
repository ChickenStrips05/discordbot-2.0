auth = 4

async def main(data):
    Newtext =''
    for i,text in enumerate(data.TextList):
        
        if i != 0:
            Newtext = Newtext+text+" "
            
    print(Newtext)
    
def help():
    return "Prints text to the terminal"
