auth = 4

async def main(data):
    Newtext =f'**There are {len(data.Files)} files**\n'
    for file in data.Files:
        Newtext = Newtext+file+'\n'
        
    embed = data.Discord.Embed(title='Files',description=Newtext)
    
    await data.Channel.send(embed= embed)
    
def help():
    return "Shows a list of all files in the commands folder."