auth = 1

async def main(data):
    catData = data.Requests.get('https://cataas.com/cat')
    
    file = open("cache/cat.jpg",'wb')
    file.write(catData.content)
    file.close
    

    discordFile = data.Discord.File(fp='cache/cat.jpg',filename='cat.jpg')
    await data.Channel.send(file=discordFile)

def help():
    return "Gets a random cat pic from the internet. Powered by cataas.com."