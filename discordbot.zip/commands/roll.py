auth = 1

async def main(data):
    
    
    try:
        if data.TextList[1]:
            try:
                sides=int(data.TextList[1])
            except:
                 await data.Channel.send("Arg 1 must be an int")
    except:
            sides=6
    
    NewText = 'You got: '+str(data.Random.randint(1,sides))
    await data.Channel.send(NewText)

def help():
    return "Rolls a dice."