auth = 2  # Set an appropriate auth level

async def main(data):
    voice_client = data.Client.voice_clients
    if voice_client and voice_client[0].is_playing():
        voice_client[0].pause()
        await data.Channel.send("Paused the music.")
    else:
        await data.Channel.send("No music is currently playing.")

def help():
    return "Pause playing music."