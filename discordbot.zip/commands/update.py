auth = 5

async def main(data):

    if data.Confirm == True:
        await data.Channel.send("Downloading the latest bot update. Ignoring all other commands until done.")
        print("Starting the update process...")

        try:
            pathlib = data.Pathlib

            
            
            update_url = data.Settings['gitUrl']
            
            if not update_url:
                await data.Channel.send("❌ No update URL provided!")
                print("Error: No update URL provided!")
                return

            print(f"Update URL: {update_url}")
            response = data.Requests.get(update_url)
            print(f"Response status code: {response.status_code}")
            
            if response.status_code != 200:
                await data.Channel.send(f"❌ Failed to download the update (HTTP {response.status_code}).")
                print(f"Error: Failed to download the update (HTTP {response.status_code})")
                return

            
            

            filename = pathlib.Path(data.Settings['gitUrl']).name

            print(filename)
            
            with open(filename,'wb') as f:
                f.write(response.content)
            
            if data.Platform == 'Windows':
                data.Os.system(f'powershell -command "Expand-Archive {filename}"')
            
            else:
                print('Unsupported server os.')
            

        except Exception as e:
            await data.Channel.send(f"❌ Update failed! Error: {e}")
            print(f"Error: {e}")

    else:
        
        with open('cache/confirm.txt', 'w') as f:
            f.write(data.FileName)
        await data.Channel.send(f"⚠️ Please confirm this action with <{data.Prefix}y> or <{data.Prefix}n> ⚠️ This action will reset the bot and may cause irreversible damage.")
        print('Confirmation requested.')

def help():
    return "Downloads and extracts the latest bot update from a remote server and restarts the bot."
