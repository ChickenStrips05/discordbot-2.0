auth = 4

async def main(data):
    if len(data.TextList) < 3:
        await data.Channel.send("Missing arguments")
        return
    
    user = data.TextList[1]
    guild = data.Message.guild

    def getAuthData():
        with open("users.json", 'r') as f:
            authdata = data.Json.loads(f.read())
        return authdata
    
    authdata = getAuthData()
    
    member = guild.get_member_named(user)
    if not member:
        await data.Channel.send('Member not found')
        return
    
    try:
        new_auth_level = int(data.TextList[2])
    except ValueError:
        await data.Channel.send("Invalid auth level. Please provide a number.")
        return
    
    if data.Auth < new_auth_level:
        await data.Channel.send("You can't assign an auth level higher than your own.")
        return
    
    # Prepare the new user data
    new_user_data = {"id": str(member.id), "lvl": new_auth_level}
    # Check if the user already exists
    user_found = False
    for i, user in enumerate(authdata["users"]):
        if user["id"] == str(member.id):  # Match user by ID
            authdata["users"][i] = new_user_data  # Replace with new data
            user_found = True
            break
    
    if not user_found:
        # Add the new user if not found
        authdata["users"].append(new_user_data)
    
    # Save the updated data
    with open('users.json', 'w') as f:
        f.write(data.Json.dumps(authdata))
    
    await data.Channel.send(f"User {'updated' if user_found else 'added'} successfully.")

def help():
    return "You can set the authorisation level for someone."
