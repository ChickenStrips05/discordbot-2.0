auth = 5

async def main(data):
    
    data.Os.execv(data.Sys.executable, ['python', f'"{__file__}"'])

def help():
    return "Restart the bot"

