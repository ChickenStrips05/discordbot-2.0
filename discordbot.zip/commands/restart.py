auth = 5

async def main(data):
    
    data.Os.system('python ' + f'"{__file__}"')

def help():
    return "Restart the bot"

