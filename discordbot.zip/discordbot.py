import discord
import os , json, random, requests, datetime, time, zipfile, sys, platform, pathlib
import yt_dlp as ytdlp

intents = discord.Intents.all()

with open('config/settings.json','r') as f:    
    settings = json.loads(f.read())
    prefix = settings["prefix"]

os.system('color')
def color(text,colorName = 'Bright White'):
    colors = {'Black':'30','Red':'31','Green':'32','Yellow':'33',
              'Blue':'34','Magenta':'35','Cyan':'36','White':'37',
              'Gray':'90','Bright Red':'91','Bright Green':'92','Bright Yellow':'93',
              'Bright Blue':'94','Bright Magenta':'95','Bright Cyan':'96','Bright White':'97'
              }
    colorCode = '\033['+ colors[colorName] +'m'

    return colorCode+text+'\033[0m'




client = discord.Client(intents=intents)




def listAllCommands():
    files = []
    for (dirpath,dirname,filename) in os.walk("commands"):
        files = filename
    
    commands =[]
    
    for file in files:
        command = ''
        if file.count('.') == 1:
            command = file.split('.')[0]
        elif file.count('.') == 0:
            command = file
        elif file.count('.') > 1:
            for i,part in enumerate(file.split('.')):

                if i<len(file.split('.'))-1:
                    command = command+part+'.'
            command = command[:-1]    
            
        if command != 'y' and command != 'n':
            commands.append(command)
            
        else:
            print(color("You can't have a command named <y> or <n>. This command will be ignored.",'Bright Red'))

    return (commands,files)

def getAuthData():
    with open("config/users.json",'r') as f:
        authdata = json.loads(f.read())
        userids = []
        for user in authdata['users']:
            userids.append(user['id'])
        userlvls = []
        for user in authdata['users']:
            userlvls.append(user['lvl'])
    return userids,userlvls



@client.event
async def on_ready():
    

    print(color(f'We have logged in as {client.user}', "Bright Magenta"))




@client.event
async def on_message(message):
    if message.author == client.user:
        return
    
    
    commands = listAllCommands()[0]
    files = listAllCommands()[1]
    text = message.content
    channel = message.channel

    
    for command in text.split('|'):
        if command.startswith(prefix):

            textList = command.split()
            textList[0] = textList[0].replace(prefix,"")

            fileName = ""
            if textList[0] == 'y' or textList[0] == 'n':
                
                fileName = textList[0]
            else:
                try:
                    fileName = files[commands.index(textList[0])]
                except:
                    await channel.send("Unknown command")


            if fileName != "" :
                if not (textList[0] == 'y' or textList[0] == 'n'):
                    file = open(f"commands/{fileName}",'r',encoding='utf-8')

                localscope = {}
                users = getAuthData()
                try:
                    auth = users[1][users[0].index(str(message.author.id))]
                except:
                    auth = 1
                
                class data:
                    Channel = channel
                    Message = message
                    Client = client
                    RawText = text
                    TextList = textList
                    Commands = commands
                    Files = files
                    Prefix = prefix
                    FileName = fileName
                    Auth = auth
                    Settings = settings
                    Color = color
                    
                    Zipfile = zipfile
                    Discord = discord
                    Random = random
                    Platform = platform.system()
                    Pathlib = pathlib
                    Os = os
                    Sys = sys
                    Requests = requests
                    Datetime = datetime
                    Json = json
                    Confirm = False
                    Ytdlp = ytdlp
                    Time = time

                print(f"{message.author} used {textList[0]}")

                
                if fileName == 'y' or fileName == 'n':

                    if fileName == 'y':
                        data.Confirm = True

                        try:
                            with open('cache/confirm.txt','r') as f:
                                with open('commands/'+f.read(),'r',encoding='utf-8') as fl:
                                    exec(fl.read(),globals(),localscope)

                                    if auth >= localscope["auth"]:
                                        await localscope['main'](data)
                                    else:
                                        await channel.send('You are not authorised to use this command')


                        except FileNotFoundError:
                            await channel.send('No ongoing confirmations')

                        try:
                            os.remove('cache/confirm.txt')
                        except FileNotFoundError:
                            pass

                    elif fileName == 'n':
                        os.remove('cache/confirm.txt')

                else:
                    exec(file.read(),globals(),localscope)

                    if auth >= localscope["auth"]:
                        await localscope['main'](data)
                    else:
                        await channel.send('You are not authorised to use this command')

                try:
                    file.close()
                except:
                    pass

            

            
            




client.run(settings["token"])
