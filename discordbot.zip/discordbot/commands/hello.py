auth = 1

async def main(data):
    await data.Channel.send(f"Hello, {data.Message.author}")

def help():
    return "Why do i have to explain this one? It's an example that interacts with the user."