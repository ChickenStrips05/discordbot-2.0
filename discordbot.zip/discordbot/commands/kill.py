auth = 5

async def main(data):
    exit(f'Closed by {data.Message.author}')

def help():
    return "Stops the python code"