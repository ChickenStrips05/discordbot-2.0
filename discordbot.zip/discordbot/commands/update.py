auth = 5

async def main(data):

    if data.Confirm == True:
        await data.Channel.send("Downloading the latest bot update. Ignoring all other commands until done.")

        try:
            # Ensure the update URL is set
            update_url = data.Settings['gitUrl']
            if not update_url:
                await data.Channel.send("❌ No update URL provided!")
                return

            response = data.Requests.get(update_url)
            if response.status_code != 200:
                await data.Channel.send(f"❌ Failed to download the update (HTTP {response.status_code}).")
                return

            zip_file = data.Io.BytesIO(response.content)

            # Extract the zip file
            try:
                with data.Zipfile.ZipFile(zip_file, 'r') as zip_ref:
                    zip_ref.extractall()  # Or specify a folder if needed
            except Exception as zip_error:
                await data.Channel.send(f"❌ Failed to extract the update: {zip_error}")
                return

            await data.Channel.send("✅ Update downloaded and extracted successfully! Restarting bot...")

            # Restart the bot
            data.Os.execv(data.Sys.executable, ['python'] + data.Sys.argv)

        except Exception as e:
            await data.Channel.send(f"❌ Update failed! Error: {e}")

    else:
        # Ask for confirmation
        with open('cache/confirm.txt', 'w') as f:
            f.write(data.FileName)
        await data.Channel.send(f"⚠️ Please confirm this action with <{data.Prefix}y> or <{data.Prefix}n> ⚠️ This action will reset the bot and may cause irreversible damage.")

def help():
    return "Downloads and extracts the latest bot update from a remote server and restarts the bot."