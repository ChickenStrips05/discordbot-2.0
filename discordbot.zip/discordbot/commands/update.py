auth = 5  # Set the required authorization level for updates (adjust as needed)

async def main(data):

    if data.Confirm == True:
        await data.Channel.send("Downloading the latest bot update...")

        try:
            # Define the URL where the latest zip file is hosted
            update_url = data.Settings['gitUrl']  # Replace with actual URL

            # Download the .zip file containing the updated bot files
            response = data.Requests.get(update_url)
            if response.status_code != 200:
                await data.Channel.send(f"Failed to download the update (HTTP {response.status_code}).")
                return

            # Open the zip file from the response content
            zip_file = data.Io.BytesIO(response.content)

            # Extract the .zip file contents into the current directory (or a specific folder)
            with data.Zipfile.ZipFile(zip_file, 'r') as zip_ref:
                # Extract all the files to the current directory (replace with your directory if needed)
                zip_ref.extractall()

            await data.Channel.send("Update downloaded and extracted successfully! Restarting bot...")

            # Restart the bot to apply the update
            data.Os.execv(data.Sys.executable, ['python'] + data.Sys.argv)

        except Exception as e:
            await data.Channel.send(f"Update failed! Error: {e}")
    else:
        with open('cache/confirm.txt','w') as f:
            f.write(data.FileName)
        await data.Channel.send(f"Please confirm this action with <{data.Prefix}y> or <{data.Prefix}n> ⚠️ This action will reset the bot. May cause irreversable dammage. ⚠️")

def help():
    return "Downloads and extracts the latest bot update from a remote server and restarts the bot."