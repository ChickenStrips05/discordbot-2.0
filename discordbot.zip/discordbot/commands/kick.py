auth = 3


async def main(data):
    if len(data.TextList)<2:
        await data.Channel.send("Missing arguments")
        return


    if data.TextList[1]:
            try:
                reason = data.TextList[2]
            except:
                reason = ''
            user = data.TextList[1]
            guild = data.Message.guild
            
            
            member = guild.get_member_named(user)
            if member:
                await member.kick(reason=reason)
                await data.Channel.send(f'{data.Message.author} has kicked {user}.')
            else:
                await data.Channel.send('Member not found')
                
    else:
          await data.Channel.send("Arg 1 must be a user.")
    

def help():
    return "Kick a user."