auth = 5

async def main(data):
    Newtext =''
    for i,text in enumerate(data.TextList):
        
        if i != 0:
            Newtext = Newtext+text+" "
            
    print(data.Color(Newtext,'Bright Yellow'))
    
def help():
    return "Prints waring text to the terminal"
