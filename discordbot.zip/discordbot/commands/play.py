auth = 2  # Set an appropriate auth level

async def main(data):
    if len(data.TextList) < 2:
        await data.Channel.send("Use a youtube url and volume from 1-100.")
        return
    

    # Ensure the user is in a voice channel
    if not data.Message.author.voice:
        await data.Channel.send("You need to be in a voice channel to use this command.")
        return

    # Ensure the bot is not already in another voice channel
    voice_client = data.Client.voice_clients
    if voice_client and voice_client[0].channel != data.Message.author.voice.channel:
        await data.Channel.send("I'm already in a different voice channel.")
        return

    # Join the user's voice channel
    if not voice_client:
        channel = data.Message.author.voice.channel
        await channel.connect()

    # Extract the YouTube URL
    url = data.TextList[1]

    # Use yt-dlp from the data class (ensure it's initialized in data class)
    try:
        ydl_opts = {
            'format': 'bestaudio/best',
            'postprocessors': [{
                'key': 'FFmpegExtractAudio',
                'preferredcodec': 'mp3',
                'preferredquality': '192',
            }],
            'quiet': True,
            'no_warnings': True,
        }

        # Using the Ytdlp instance from the data class
        with data.Ytdlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            audio_url = info['url']

        voice_client = data.Client.voice_clients[0]
        if voice_client.is_playing():
            voice_client.stop()

        # Play the audio using FFmpeg
        voice_client.play(
            data.Discord.FFmpegPCMAudio(source=audio_url, before_options='-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5',executable="ffmpeg"),
            
        )
        await data.Channel.send(f"Now playing: {url}")
    except Exception as e:
        await data.Channel.send(f"Error: {str(e)}")

def help():
    return "Play a song with a youtube url."