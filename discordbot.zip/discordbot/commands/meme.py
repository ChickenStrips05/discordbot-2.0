auth = 1

async def main(data):
    headers = {'x-api-key': '7c9941781c56485b95dc1c3b12b83645'}

    if len(data.TextList) > 1:
        memeData = data.Requests.get('https://api.apileague.com/retrieve-random-meme?keywords='+data.TextList[1], headers = headers)
    else:
        memeData = data.Requests.get('https://api.apileague.com/retrieve-random-meme', headers = headers)
    
    imageData = data.Requests.get(data.Json.loads(memeData.content.decode('utf-8'))['url'])

    file = open("cache/meme.jpg",'wb')
    file.write(imageData.content)
    file.close
    

    discordFile = data.Discord.File(fp='cache/meme.jpg',filename='meme.jpg')
    await data.Channel.send(file=discordFile)

def help():
    return "Gets a random meme from the internet. You can also set keywords. Powered by apileague.com."