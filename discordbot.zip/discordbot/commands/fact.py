auth = 1

async def main(data):
    catData = data.Requests.get('https://uselessfacts.jsph.pl/api/v2/facts/random?language=en')
    
    
    await data.Channel.send(data.Json.loads(catData.content.decode('utf-8'))['text'])

def help():
    return "Gets a random fact from the internet. Powered by uselessfacts.jsph.pl."